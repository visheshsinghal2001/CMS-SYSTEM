<?php
  session_start();
    if(!isset($_SESSION['user_id']))  // user check
    {
      header("location:../Logout.php");    
    }

    require '../init.php';
    $uid=$_SESSION['user_id'];
    $proj_id=$_REQUEST['proj_id'];
    $func = new operation();
    $r=$func->select_with_condition("*","user_project","user_id=$uid and project_id=$proj_id");
    if($r==false){
      header("location:unauth.php"); 
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Description</title>
</head>
<body>
    <?php
    
     $r=$func->select_with_condition("*","project","project_id=$proj_id");
     $row=mysqli_fetch_array($r);
     ?>
     <h2><?php echo $row['project_name'] ?></h2>
     <?php
     if($uid==$row["FinishID"]){
?>
<div class="confirm">
  <form id=end>
<input type=submit value=complete name=complete>
<input type=submit value=delete name=delete>
    </form>
</div>
      <?php
     }
     ?>
     <span class="created"><?echo $row[''] ?></span>
     <p><?php echo $row['project_description'];?><p>
       <?php
      
      $r=$func->select_with_join_condition("*","task","inner join","user","task_receiver=user_id","task_project=$proj_id and task_display=1 order by dead_line");
      $r2=$func->select_with_join_condition("*","task","inner join","user","task_receiver=user_id","task_project=$proj_id and task_display=0 order by task_complete desc");
      $tot=mysqli_num_rows($r);
      $comp=mysqli_num_rows($r2);
      ?>
      <label for="file">Project progress:</label>
   <progress id="file" value=<?php echo $comp;?> max=<?php echo ($tot+$comp);?>> <?php $comp*100/($tot+$comp);?></progress>
<div class="remaining">
  
  <?php
      while($row2=mysqli_fetch_array($r)){
        echo "<table>";
 ?>
        <tr>
          <td><?php echo $row2["user_image"] ?></td>
          <td><?php echo $row2["user_fname"]." ".$row2["user_lname"];?></td>
          <td><?php echo $row2["task_name"] ?></td>
          <td><?php echo $row2["dead_line"]?></td>
          <td><a href="UserTaskDetails.php?task_id=<?php echo $row2["task_id"]?>&proj_id=<?php echo $proj_id?>">More details</a></td>
      </tr>

      <?php
      } 
      ?>
 </div>
<div class="completed">
  Completed Task
  <?php
      while($row2=mysqli_fetch_array($r2)){
        echo "<table>";
 ?>
        <tr>
          <td><?php echo $row2["user_image"] ?></td>
          <td><?php echo $row2["user_fname"]." ".$row2["user_lname"];?></td>
          <td><?php echo $row2["task_name"] ?></td>
          <td><?php echo $row2["task_complete"]?></td>
          <td><a href="UserTaskDetails.php?task_id=<?php echo $row2["task_id"]?>&proj_id=<?php echo $proj_id?>">More details</a></td>
      </tr>

      <?php
      } 
      ?>
 </div>

      <?php
      if($_SESSION["zval"]<=$row["authZval"]){
        
        ?>
        <a href="taskassign.php?proj_id=<?php echo $proj_id?>" >Assign Task</a>
<?php
      }
       ?>
    
      <!-- task you assigned for this project -->
      

    
    
</body>
</html>