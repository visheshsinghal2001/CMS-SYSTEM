<?php
  session_start();
    if(!isset($_SESSION['user_id']))  // user check
    {
      header("location:../Logout.php");    
    }

    require '../init.php';
    $func = new operation();
    date_default_timezone_set("Asia/Kolkata");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Task Details</title>
  <script src="javascript/FillDate.js"></script>
</head>
<body>
  
  <?php
   $task_id=$_REQUEST['task_id']; 
   $proj_id=$_REQUEST['proj_id'];
  
   $r=$func->select_with_condition("*","task","task_id=$task_id;");
   $row=mysqli_fetch_array($r);
  
    
   
  $sender=$row["task_sender"];
  $receiver=$row["task_receiver"];
  $rx=$func->select_with_condition("user_image,user_fname,user_lname","user","user_id=$receiver;");
  $rx=mysqli_fetch_array($rx);
?>

   <h2><?php echo($row['task_name']); ?></h2>
  <!-- Sender name and will redirect to user page -->
  <a href="userinfo.php?userid=<?php echo($sender); ?>">
  <div class="sender">
    
    <img class="icon" src=<?php echo $row["task_sender_image"]?> alt="Sender Image">
    <span class="name"><?php echo $row["task_sender_name"]?></span>
  </div>
  </a>
  <!-- reciever ka info -->
  <a href="userinfo.php?userid=<?php echo($uid); ?>">
  <div class="sender">
    
    <img class="icon" src=<?php echo $rx['user_image']?> alt="reciever Image">
    <span class="name"><?php echo $rx["user_fname"]." ".$rx["user_lname"];?></span>
  </div>
  </a>

  <!-- Task description -->
  <div class="decription">
  <?php echo($row['task_details']); ?>
  </div>
  <div class="project"></div>
 <?php
  $r2=$func->select_with_condition("*","project","project_id=$proj_id;");   
  $row2=mysqli_fetch_array($r2);
 ?>

 <div class="project">

    <div class="name">

      <!-- Project name and redirect to project page on clicking name -->
      <a href="project.php?proj_id=<?php echo $proj_id ?>">
        <span class="projname">
          
          <?php echo($row2['project_name']); ?>
        </span>   
      </a>
    </div>
  <div class="deadline div">
 
    deadline:
    <?php 
    $dead=$row["dead_line"];
    // $dead.=":00";
    echo ($dead);
    ?>
  </div>

<div class="timeRemaing">

  <span id=countdown></span>
  </div>
</div>
<?php 
       if($row["task_display"]!=0){
      echo strtotime($row["dead_line"]);
      $dead=strtotime($row["dead_line"])-time();
      $dead*=1000;
      echo "<script>FillDate($dead)</script>";
      if($_SESSION['user_id']==$receiver){
      ?>
       <form method=post>
   <input type="submit" name="complete" value="mark as complete">
    </form>
      <?php
      }
       }
      else {
        // create javascript function to fill task completed in deadline 
        //or go and have new feature pending or completed upto you.
       echo "<script>completed_task()</script>";
      }
      ?>
<!-- task complete button -->

<?php
if(isset($_POST["complete"])){
$r=  $func->update("task","task_display=0","task_id=$task_id");
if($r==false)echo "error"; 
else{

  echo "<script>completed_task()</script>";
}
}

?>
</body>
</html>